$routes->get('emailsender', 'EmailSender::index');
$routes->post('emailsender/sendemails', 'EmailSender::sendEmails');
