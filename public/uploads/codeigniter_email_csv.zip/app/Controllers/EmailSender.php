<?php

namespace App\Controllers;
use CodeIgniter\Controller;
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

class EmailSender extends Controller
{
    public function index()
    {
        return view('upload_form');
    }

    public function sendEmails()
    {
        helper(['form', 'url']);

        $file = $this->request->getFile('csv_file');
        if ($file && $file->isValid() && !$file->hasMoved()) {
            $newName = $file->getRandomName();
            $file->move(WRITEPATH . 'uploads', $newName);

            $filePath = WRITEPATH . 'uploads/' . $newName;

            // Load PHPMailer
            require_once ROOTPATH . 'vendor/autoload.php';
            $mail = new PHPMailer(true);

            // Configure SMTP
            $mail->isSMTP();
            $mail->Host = 'smtp.example.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'your_email@example.com';
            $mail->Password = 'your_password';
            $mail->SMTPSecure = 'tls';
            $mail->Port = 587;
            $mail->setFrom('your_email@example.com', 'Your Name');

            $mail->isHTML(false);
            $mail->Subject = 'Test Email from CSV Upload';

            $handle = fopen($filePath, "r");
            $results = [];

            $firstLine = true;
            while (($data = fgetcsv($handle, 1000, ",")) !== false) {
                if ($firstLine) {
                    $firstLine = false;
                    continue;
                }

                if (count($data) < 4) {
                    $results[] = "⚠️ Skipped row with missing columns.";
                    continue;
                }

                $email = trim($data[0]);
                $firstName = trim($data[1]);
                $lastName = trim($data[2]);
                $customMessage = trim($data[3]);

                if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    try {
                        $mail->clearAddresses();
                        $mail->addAddress($email);
                        $mail->Body = "Hello $firstName $lastName,\n\n$customMessage\n\nBest regards,\nYour Company";
                        $mail->send();
                        $results[] = "✅ Email sent to $email";
                    } catch (Exception $e) {
                        $results[] = "❌ Failed to send to $email: {$mail->ErrorInfo}";
                    }
                } else {
                    $results[] = "⚠️ Invalid email: $email";
                }
            }
            fclose($handle);

            return view('upload_form', ['results' => $results]);
        } else {
            return redirect()->back()->with('error', 'Invalid file upload.');
        }
    }
}
