<!DOCTYPE html>
<html>
<head>
    <title>Upload CSV to Send Emails</title>
</head>
<body>
    <h2>Upload CSV File</h2>

    <?php if (session()->getFlashdata('error')): ?>
        <p style="color:red"><?= session()->getFlashdata('error') ?></p>
    <?php endif; ?>

    <form method="post" action="<?= base_url('emailsender/sendemails') ?>" enctype="multipart/form-data">
        <input type="file" name="csv_file" accept=".csv" required>
        <button type="submit">Upload & Send Emails</button>
    </form>

    <?php if (isset($results)): ?>
        <h3>Results:</h3>
        <ul>
            <?php foreach ($results as $line): ?>
                <li><?= esc($line) ?></li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>
</body>
</html>
